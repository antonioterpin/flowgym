"""Module for common utils."""
