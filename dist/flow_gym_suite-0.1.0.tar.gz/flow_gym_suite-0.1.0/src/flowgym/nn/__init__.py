"""Module for nn utils."""
