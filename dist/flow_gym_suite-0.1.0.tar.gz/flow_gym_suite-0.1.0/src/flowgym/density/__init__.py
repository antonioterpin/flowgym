"""Module for density estimators."""
