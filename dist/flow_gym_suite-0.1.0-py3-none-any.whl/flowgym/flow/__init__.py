"""Module for flow estimators."""
