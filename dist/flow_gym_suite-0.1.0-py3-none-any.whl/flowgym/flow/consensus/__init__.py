"""Module for the consensus structure in flow estimation."""

from .consensus import ConsensusFlowEstimator

__all__ = [
    "ConsensusFlowEstimator",
]
